"""Enter point."""

from brain_games.games.even import play_even


def main() -> None:
    """Start game of even."""
    play_even()


if __name__ == '__main__':
    main()
