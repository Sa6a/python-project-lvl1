"""Mini games."""
