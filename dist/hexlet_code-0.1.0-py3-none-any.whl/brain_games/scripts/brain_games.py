"""Enter point."""

from brain_games.cli import welcome_user


def main() -> None:
    """Say hi and get name user."""
    welcome_user()


if __name__ == '__main__':
    main()
