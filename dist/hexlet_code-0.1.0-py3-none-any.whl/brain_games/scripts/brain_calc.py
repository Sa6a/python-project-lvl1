"""Enter point."""

from brain_games.games.calc import play_calc


def main() -> None:
    """Start game of even."""
    play_calc()


if __name__ == '__main__':
    main()
